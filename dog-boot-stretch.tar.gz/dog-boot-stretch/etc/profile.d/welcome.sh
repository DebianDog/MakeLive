#!/bin/sh

cat /opt/docs/welcome &
